// Minimal SDK stub for documentation downloads
export function initTracker(config) {
  if (!config || !config.trackerId) {
    throw new Error('trackerId is required');
  }
  const state = { ...config };
  return {
    track(eventName, payload = {}) {
      console.log('Tracking event', eventName, payload, state);
    },
  };
}
