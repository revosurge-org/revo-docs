# Web Tracker SDK

This lightweight bundle accompanies the RevoSurge docs.

## Contents
- `web-tracker-1.2.0.js`: ES module export with a minimal tracker stub.
- `example.html`: Shows how to include and initialize the SDK.

## Usage
1. Serve the script somewhere accessible to your app.
2. Import it and call `initTracker` with your configuration.
3. Use the returned `track` helper to emit events.

This archive is for documentation demos and does not reflect production code.
